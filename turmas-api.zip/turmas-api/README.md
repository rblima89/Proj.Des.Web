# turmas-api (fix)

Use `mvn -U clean spring-boot:run` para executar.
Se precisar do Postgres via Docker: `docker compose up -d` na raiz (onde está `docker-compose.yml`).
