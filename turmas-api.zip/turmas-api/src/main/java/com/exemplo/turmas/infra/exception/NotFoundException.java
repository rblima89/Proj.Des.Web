package com.exemplo.turmas.infra.exception;

public class NotFoundException extends RuntimeException {
    public NotFoundException(String msg){ super(msg); }
}
